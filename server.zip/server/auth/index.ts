/* ================================
  TL;DR  -->  admin auth guard

  - protects write mutations (crud)
  - keeps auth logic out of resolvers/services
================================ */
