/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  TL;DR  -->  server-only types

  - types for context, auth, db row shapes
  - defines langgraph state shape + keeps ai pipeline predictable
  - keeps backend internals out of shared types
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
