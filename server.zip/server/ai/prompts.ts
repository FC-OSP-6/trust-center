/* ================================
  TL;DR  -->  AI prompts + formatting

  - keeps prompts consistent and editable
  - forces citations and "no invention"
================================ */
