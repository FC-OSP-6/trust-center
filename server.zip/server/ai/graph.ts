/* ================================
  TL;DR  -->  ai orchestration (langgraph)

  - runs retrieve -> generate -> validate -> format
  - central entrypoint used by graphql mutation
================================ */
