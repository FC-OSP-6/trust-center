/* ================================
  TL;DR  -->  retrieval + kb wrapper

  - provides a single search(question) api
  - can start with keyword search, later add embeddings
================================ */
